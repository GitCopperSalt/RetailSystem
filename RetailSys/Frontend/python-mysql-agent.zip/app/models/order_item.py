from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from decimal import Decimal

@dataclass
class OrderItem:
    id: Optional[int] = None
    order_id: Optional[int] = None
    item_id: Optional[int] = None
    item_name: Optional[str] = None
    item_price: Optional[Decimal] = None
    quantity: Optional[int] = None
    create_time: Optional[datetime] = None
    update_time: Optional[datetime] = None
