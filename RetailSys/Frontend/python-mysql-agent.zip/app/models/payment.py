from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from decimal import Decimal

@dataclass
class Payment:
    id: Optional[int] = None
    order_id: Optional[int] = None
    user_id: Optional[int] = None
    amount: Optional[Decimal] = None
    payment_method: Optional[str] = None  # ALIPAY, WECHAT, CREDIT_CARD
    status: Optional[str] = None  # PENDING, SUCCESS, FAILED
    transaction_id: Optional[str] = None
    create_time: Optional[datetime] = None
    update_time: Optional[datetime] = None
