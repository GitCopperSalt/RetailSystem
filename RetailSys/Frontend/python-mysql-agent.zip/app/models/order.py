from dataclasses import dataclass
from datetime import datetime
from typing import Optional, List
from decimal import Decimal

@dataclass
class Order:
    id: Optional[int] = None
    user_id: Optional[int] = None
    total_amount: Optional[Decimal] = None
    status: Optional[str] = None  # PENDING, PAID, SHIPPED, DELIVERED, CANCELLED
    create_time: Optional[datetime] = None
    update_time: Optional[datetime] = None
    items: Optional[List['OrderItem']] = None
