import mysql.connector
from mysql.connector import Error
from app.config import settings

def get_db_connection():
    """获取数据库连接"""
    connection = None
    try:
        connection = mysql.connector.connect(
            host=settings.mysql_host,
            port=settings.mysql_port,
            database=settings.mysql_db,
            user=settings.mysql_user,
            password=settings.mysql_password,
            charset='utf8mb4'
        )
    except Error as e:
        print(f"数据库连接错误: {e}")
    return connection

def close_db_connection(connection):
    """关闭数据库连接"""
    if connection and connection.is_connected():
        connection.close()
