from langchain.tools import tool
from pydantic import BaseModel, Field
from app.services.user_service import UserService
from app.services.order_service import OrderService
from app.services.pay_service import PayService
from app.models.user import User
from app.models.order_item import OrderItem

# 初始化服务
user_service = UserService()
order_service = OrderService()
pay_service = PayService()

# 用户相关工具
class GetUserByIdRequest(BaseModel):
    user_id: int = Field(description="用户ID")

@tool("get_user_by_id", args_schema=GetUserByIdRequest)
def get_user_by_id(user_id: int) -> dict:
    """根据用户ID获取用户信息"""
    user = user_service.get_user_by_id(user_id)
    if user:
        return {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "create_time": user.create_time.isoformat() if user.create_time else None
        }
    return {"error": "用户不存在"}

class CreateUserRequest(BaseModel):
    username: str = Field(description="用户名")
    password: str = Field(description="密码")
    email: str = Field(description="邮箱")

@tool("create_user", args_schema=CreateUserRequest)
def create_user(username: str, password: str, email: str) -> dict:
    """创建新用户"""
    user = User(username=username, password=password, email=email)
    success = user_service.create_user(user)
    return {"success": success}

# 订单相关工具
class CreateOrderRequest(BaseModel):
    user_id: int = Field(description="用户ID")
    items: list[dict] = Field(description="订单项列表，每个项包含item_id和quantity")

@tool("create_order", args_schema=CreateOrderRequest)
def create_order(user_id: int, items: list[dict]) -> dict:
    """创建新订单"""
    order_items = [OrderItem(item_id=item["item_id"], quantity=item["quantity"]) for item in items]
    order = order_service.create_order(user_id, order_items)
    if order:
        return {
            "order_id": order.id, 
            "status": order.status, 
            "total_amount": str(order.total_amount),
            "items": [{"item_id": item.item_id, "quantity": item.quantity} for item in order.items]
        }
    return {"error": "创建订单失败"}

class GetOrderByIdRequest(BaseModel):
    order_id: int = Field(description="订单ID")

@tool("get_order_by_id", args_schema=GetOrderByIdRequest)
def get_order_by_id(order_id: int) -> dict:
    """根据订单ID获取订单信息"""
    order = order_service.get_order_by_id(order_id)
    if order:
        return {
            "order_id": order.id,
            "user_id": order.user_id,
            "total_amount": str(order.total_amount),
            "status": order.status,
            "create_time": order.create_time.isoformat() if order.create_time else None,
            "items": [
                {
                    "item_id": item.item_id,
                    "item_name": item.item_name,
                    "item_price": str(item.item_price),
                    "quantity": item.quantity
                } for item in order.items
            ]
        }
    return {"error": "订单不存在"}

# 支付相关工具
class CreatePaymentRequest(BaseModel):
    order_id: int = Field(description="订单ID")
    user_id: int = Field(description="用户ID")
    payment_method: str = Field(description="支付方式，如ALIPAY, WECHAT, CREDIT_CARD")

@tool("create_payment", args_schema=CreatePaymentRequest)
def create_payment(order_id: int, user_id: int, payment_method: str) -> dict:
    """创建支付记录"""
    payment = pay_service.create_payment(order_id, user_id, payment_method)
    if payment:
        return {
            "payment_id": payment.id,
            "order_id": payment.order_id,
            "amount": str(payment.amount),
            "payment_method": payment.payment_method,
            "status": payment.status,
            "transaction_id": payment.transaction_id
        }
    return {"error": "创建支付记录失败"}

class UpdatePaymentStatusRequest(BaseModel):
    payment_id: int = Field(description="支付ID")
    status: str = Field(description="支付状态，如SUCCESS, FAILED")

@tool("update_payment_status", args_schema=UpdatePaymentStatusRequest)
def update_payment_status(payment_id: int, status: str) -> dict:
    """更新支付状态"""
    success = pay_service.update_payment_status(payment_id, status)
    return {"success": success}
