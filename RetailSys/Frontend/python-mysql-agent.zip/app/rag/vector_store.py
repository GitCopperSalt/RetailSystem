import chromadb
from chromadb.config import Settings
from langchain.document_loaders import TextLoader
from langchain.text_splitter import TokenTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from app.config import settings

def initialize_vector_store():
    """初始化向量存储，加载服务条款文档"""
    # 初始化Chroma向量存储
    client = chromadb.Client(Settings(
        persist_directory="./chroma_db",
        anonymized_telemetry=False
    ))
    
    # 检查集合是否存在，不存在则创建并加载文档
    collection = client.get_or_create_collection(name="terms_of_service")
    if collection.count() == 0:
        try:
            # 加载服务条款文档
            loader = TextLoader("resources/rag/terms-of-service.txt", encoding="utf-8")
            documents = loader.load()
            
            # 拆分文档
            text_splitter = TokenTextSplitter(chunk_size=500, chunk_overlap=50)
            splits = text_splitter.split_documents(documents)
            
            # 生成嵌入并添加到向量库
            embeddings = OpenAIEmbeddings(api_key=settings.llm_api_key)
            for i, doc in enumerate(splits):
                embedding = embeddings.embed_query(doc.page_content)
                collection.add(
                    ids=[f"doc_{i}"],
                    embeddings=[embedding],
                    documents=[doc.page_content]
                )
            client.persist()
            print("向量存储初始化完成")
        except Exception as e:
            print(f"向量存储初始化失败: {e}")
    
    return collection

def query_terms(query: str, top_k: int = 3) -> list[str]:
    """查询服务条款相关内容"""
    try:
        client = chromadb.Client(Settings(
            persist_directory="./chroma_db",
            anonymized_telemetry=False
        ))
        collection = client.get_collection(name="terms_of_service")
        
        embeddings = OpenAIEmbeddings(api_key=settings.llm_api_key)
        query_embedding = embeddings.embed_query(query)
        
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k
        )
        
        return results["documents"][0] if results["documents"] else []
    except Exception as e:
        print(f"查询服务条款失败: {e}")
        return []
