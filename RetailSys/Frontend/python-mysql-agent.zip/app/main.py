from fastapi import FastAPI
from langchain.agents import initialize_agent, AgentType
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from app.tools.custom_tools import *
from app.config import settings
from app.rag.vector_store import initialize_vector_store, query_terms

app = FastAPI(title="Python AI Agent with MySQL")

# 初始化向量存储
initialize_vector_store()

# 添加RAG工具
class QueryTermsRequest(BaseModel):
    query: str = Field(description="查询服务条款的问题")

@tool("query_terms", args_schema=QueryTermsRequest)
def query_terms_tool(query: str) -> dict:
    """查询服务条款相关内容"""
    results = query_terms(query)
    return {"results": results}

# 初始化LLM和Agent
def get_agent():
    llm = ChatOpenAI(api_key=settings.llm_api_key, model_name="gpt-3.5-turbo")
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    tools = [
        get_user_by_id,
        create_user,
        create_order,
        get_order_by_id,
        create_payment,
        update_payment_status,
        query_terms_tool
    ]
    return initialize_agent(
        tools, llm, agent=AgentType.CHAT_CONVERSATIONAL_REACT_DESCRIPTION,
        memory=memory, verbose=True
    )

@app.get("/chat")
def chat(chat_id: str, message: str):
    agent = get_agent()
    prompt = f"""
    数据库配置信息如下:
    MYSQL_HOST: {settings.mysql_host}
    MYSQL_USER: {settings.mysql_user}
    MYSQL_PASSWORD: {settings.mysql_password}
    MYSQL_DATABASE: {settings.mysql_db}
    {message}
    执行命令后，说明你使用的工具名称和来源
    """
    response = agent.run(prompt)
    return {"response": response}

@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "python-ai-agent"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=settings.server_host, port=settings.server_port)
