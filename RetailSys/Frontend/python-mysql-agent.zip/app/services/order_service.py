from app.models.order import Order
from app.models.order_item import OrderItem
from app.database import get_db_connection, close_db_connection
from app.services.item_service import ItemService
from app.services.user_service import UserService
from datetime import datetime
from decimal import Decimal
from mysql.connector import Error

class OrderService:
    def __init__(self):
        self.item_service = ItemService()
        self.user_service = UserService()

    def create_order(self, user_id: int, items: list[OrderItem]) -> Order:
        """创建新订单"""
        if not user_id or not items:
            print("无效的订单参数")
            return None

        # 检查用户是否存在
        if not self.user_service.get_user_by_id(user_id):
            print(f"用户不存在: {user_id}")
            return None

        connection = get_db_connection()
        try:
            connection.start_transaction()
            cursor = connection.cursor(dictionary=True)

            # 计算总金额并验证商品
            total_amount = Decimal('0.00')
            valid_items = []
            
            for item in items:
                item_info = self.item_service.get_item_by_id(item.item_id)
                if not item_info:
                    raise Exception(f"商品不存在: {item.item_id}")
                
                if item_info.stock < item.quantity:
                    raise Exception(f"商品库存不足: {item_info.name}")

                item_total = item_info.price * Decimal(str(item.quantity))
                total_amount += item_total

                valid_items.append({
                    "item_id": item.item_id,
                    "name": item_info.name,
                    "price": item_info.price,
                    "quantity": item.quantity
                })

            # 创建订单主记录
            order_query = """
                INSERT INTO orders (user_id, total_amount, status, create_time, update_time)
                VALUES (%s, %s, %s, %s, %s)
            """
            now = datetime.now()
            cursor.execute(order_query, (
                user_id,
                total_amount,
                "PENDING",
                now,
                now
            ))
            order_id = cursor.lastrowid

            # 插入订单项
            item_query = """
                INSERT INTO order_items 
                (order_id, item_id, item_name, item_price, quantity, create_time, update_time)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            item_values = []
            for item in valid_items:
                item_values.append((
                    order_id,
                    item["item_id"],
                    item["name"],
                    item["price"],
                    item["quantity"],
                    now,
                    now
                ))
            cursor.executemany(item_query, item_values)

            # 减少库存
            for item in valid_items:
                if not self.item_service.decrease_stock(
                    item["item_id"], 
                    item["quantity"],
                    connection,
                    cursor
                ):
                    raise Exception(f"库存更新失败: {item['item_id']}")

            connection.commit()
            return self.get_order_by_id(order_id)

        except Exception as e:
            print(f"创建订单失败: {e}")
            connection.rollback()
            return None
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)

    def get_order_by_id(self, order_id: int) -> Order:
        """根据订单ID查询订单"""
        if not order_id:
            print("订单ID不能为空")
            return None
            
        connection = get_db_connection()
        order = None
        try:
            cursor = connection.cursor(dictionary=True)
            
            # 查询订单主信息
            order_query = """
                SELECT id, user_id, total_amount, status, create_time, update_time 
                FROM orders 
                WHERE id = %s
            """
            cursor.execute(order_query, (order_id,))
            order_result = cursor.fetchone()
            
            if not order_result:
                return None
                
            # 查询订单项
            items_query = """
                SELECT id, order_id, item_id, item_name, item_price, quantity, create_time, update_time 
                FROM order_items 
                WHERE order_id = %s
            """
            cursor.execute(items_query, (order_id,))
            items_result = cursor.fetchall()
            
            # 构建订单项列表
            order_items = []
            for item in items_result:
                order_items.append(OrderItem(
                    id=item['id'],
                    order_id=item['order_id'],
                    item_id=item['item_id'],
                    item_name=item['item_name'],
                    item_price=item['item_price'],
                    quantity=item['quantity'],
                    create_time=item['create_time'],
                    update_time=item['update_time']
                ))
            
            # 构建订单对象
            order = Order(
                id=order_result['id'],
                user_id=order_result['user_id'],
                total_amount=order_result['total_amount'],
                status=order_result['status'],
                create_time=order_result['create_time'],
                update_time=order_result['update_time'],
                items=order_items
            )
            
        except Error as e:
            print(f"查询订单失败: {e}")
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)
        return order

    def update_order_status(self, order_id: int, status: str) -> bool:
        """更新订单状态"""
        if not order_id or not status:
            print("订单ID和状态不能为空")
            return False
            
        connection = get_db_connection()
        try:
            cursor = connection.cursor()
            query = """
                UPDATE orders 
                SET status = %s, update_time = %s
                WHERE id = %s
            """
            now = datetime.now()
            cursor.execute(query, (status, now, order_id))
            connection.commit()
            return cursor.rowcount > 0
        except Error as e:
            print(f"更新订单状态失败: {e}")
            connection.rollback()
            return False
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)
