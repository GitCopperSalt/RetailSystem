from app.models.payment import Payment
from app.database import get_db_connection, close_db_connection
from app.services.order_service import OrderService
from datetime import datetime
from decimal import Decimal
from mysql.connector import Error
import uuid

class PayService:
    def __init__(self):
        self.order_service = OrderService()

    def create_payment(self, order_id: int, user_id: int, payment_method: str) -> Payment:
        """创建支付记录"""
        if not order_id or not user_id or not payment_method:
            print("无效的支付参数")
            return None
            
        # 检查订单是否存在
        order = self.order_service.get_order_by_id(order_id)
        if not order:
            print(f"订单不存在: {order_id}")
            return None
            
        # 检查订单归属
        if order.user_id != user_id:
            print(f"订单不属于用户: {user_id}")
            return None
            
        # 检查订单状态
        if order.status != "PENDING":
            print(f"订单状态异常: {order.status}")
            return None

        connection = get_db_connection()
        try:
            connection.start_transaction()
            cursor = connection.cursor(dictionary=True)
            
            # 创建支付记录
            payment_query = """
                INSERT INTO payments 
                (order_id, user_id, amount, payment_method, status, transaction_id, create_time, update_time)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            now = datetime.now()
            transaction_id = str(uuid.uuid4())  # 生成唯一交易ID
            values = (
                order_id,
                user_id,
                order.total_amount,
                payment_method,
                "PENDING",
                transaction_id,
                now,
                now
            )
            cursor.execute(payment_query, values)
            payment_id = cursor.lastrowid
            
            connection.commit()
            return self.get_payment_by_id(payment_id)
            
        except Error as e:
            print(f"创建支付记录失败: {e}")
            connection.rollback()
            return None
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)

    def get_payment_by_id(self, payment_id: int) -> Payment:
        """根据支付ID查询支付记录"""
        if not payment_id:
            print("支付ID不能为空")
            return None
            
        connection = get_db_connection()
        payment = None
        try:
            cursor = connection.cursor(dictionary=True)
            query = """
                SELECT id, order_id, user_id, amount, payment_method, status, 
                       transaction_id, create_time, update_time 
                FROM payments 
                WHERE id = %s
            """
            cursor.execute(query, (payment_id,))
            result = cursor.fetchone()
            
            if result:
                payment = Payment(
                    id=result['id'],
                    order_id=result['order_id'],
                    user_id=result['user_id'],
                    amount=result['amount'],
                    payment_method=result['payment_method'],
                    status=result['status'],
                    transaction_id=result['transaction_id'],
                    create_time=result['create_time'],
                    update_time=result['update_time']
                )
        except Error as e:
            print(f"查询支付记录失败: {e}")
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)
        return payment

    def update_payment_status(self, payment_id: int, status: str) -> bool:
        """更新支付状态"""
        if not payment_id or not status:
            print("支付ID和状态不能为空")
            return False
            
        connection = get_db_connection()
        try:
            connection.start_transaction()
            cursor = connection.cursor()
            
            # 获取当前支付记录
            cursor.execute("SELECT order_id FROM payments WHERE id = %s", (payment_id,))
            result = cursor.fetchone()
            if not result:
                raise Exception(f"支付记录不存在: {payment_id}")
            order_id = result[0]
            
            # 更新支付状态
            payment_query = """
                UPDATE payments 
                SET status = %s, update_time = %s
                WHERE id = %s
            """
            now = datetime.now()
            cursor.execute(payment_query, (status, now, payment_id))
            
            # 如果支付成功，更新订单状态
            if status == "SUCCESS":
                if not self.order_service.update_order_status(order_id, "PAID"):
                    raise Exception("更新订单状态失败")
            
            connection.commit()
            return cursor.rowcount > 0
        except Exception as e:
            print(f"更新支付状态失败: {e}")
            connection.rollback()
            return False
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)
