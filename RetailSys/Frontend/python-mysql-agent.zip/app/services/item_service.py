from app.models.item import Item
from app.database import get_db_connection, close_db_connection
from datetime import datetime
from mysql.connector import Error, cursor

class ItemService:
    def get_item_by_id(self, item_id: int) -> Item:
        """根据商品ID查询商品信息"""
        if not item_id:
            print("商品ID不能为空")
            return None
            
        connection = get_db_connection()
        item = None
        try:
            cursor = connection.cursor(dictionary=True)
            query = """
                SELECT id, name, description, price, stock, create_time, update_time 
                FROM items 
                WHERE id = %s
            """
            cursor.execute(query, (item_id,))
            result = cursor.fetchone()
            
            if result:
                item = Item(
                    id=result['id'],
                    name=result['name'],
                    description=result['description'],
                    price=result['price'],
                    stock=result['stock'],
                    create_time=result['create_time'],
                    update_time=result['update_time']
                )
        except Error as e:
            print(f"查询商品失败: {e}")
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)
        return item

    def decrease_stock(self, item_id: int, quantity: int, connection, cursor: cursor.MySQLCursor) -> bool:
        """减少商品库存"""
        if not item_id or quantity <= 0:
            print("无效的库存更新参数")
            return False
            
        try:
            query = """
                UPDATE items 
                SET stock = stock - %s, update_time = %s
                WHERE id = %s AND stock >= %s
            """
            now = datetime.now()
            cursor.execute(query, (quantity, now, item_id, quantity))
            return cursor.rowcount > 0
        except Error as e:
            print(f"更新库存失败: {e}")
            return False
