from app.models.user import User
from app.database import get_db_connection, close_db_connection
from datetime import datetime
from mysql.connector import Error

class UserService:
    def get_user_by_id(self, user_id: int) -> User:
        """根据用户ID查询用户信息"""
        if not user_id:
            print("用户ID不能为空")
            return None
            
        connection = get_db_connection()
        user = None
        try:
            cursor = connection.cursor(dictionary=True)
            query = """
                SELECT id, username, password, email, create_time, update_time 
                FROM users 
                WHERE id = %s
            """
            cursor.execute(query, (user_id,))
            result = cursor.fetchone()
            
            if result:
                user = User(
                    id=result['id'],
                    username=result['username'],
                    password=result['password'],
                    email=result['email'],
                    create_time=result['create_time'],
                    update_time=result['update_time']
                )
        except Error as e:
            print(f"查询用户失败: {e}")
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)
        return user

    def create_user(self, user: User) -> bool:
        """创建新用户"""
        if not user or not user.username or not user.password:
            print("无效的用户数据")
            return False
            
        connection = get_db_connection()
        try:
            cursor = connection.cursor()
            query = """
                INSERT INTO users (username, password, email, create_time, update_time)
                VALUES (%s, %s, %s, %s, %s)
            """
            now = datetime.now()
            values = (
                user.username,
                user.password,  # 实际应用中需要加密处理
                user.email,
                now,
                now
            )
            cursor.execute(query, values)
            connection.commit()
            return cursor.rowcount > 0
        except Error as e:
            print(f"创建用户失败: {e}")
            connection.rollback()
            return False
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)

    def update_user(self, user: User) -> bool:
        """更新用户信息"""
        if not user or not user.id:
            print("用户ID不能为空")
            return False
            
        connection = get_db_connection()
        try:
            cursor = connection.cursor()
            query = """
                UPDATE users 
                SET username = %s, password = %s, email = %s, update_time = %s
                WHERE id = %s
            """
            now = datetime.now()
            values = (
                user.username,
                user.password,  # 实际应用中需要加密处理
                user.email,
                now,
                user.id
            )
            cursor.execute(query, values)
            connection.commit()
            return cursor.rowcount > 0
        except Error as e:
            print(f"更新用户失败: {e}")
            connection.rollback()
            return False
        finally:
            if connection:
                cursor.close()
                close_db_connection(connection)
