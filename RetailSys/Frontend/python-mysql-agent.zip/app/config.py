from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # 服务器配置
    server_host: str = "0.0.0.0"
    server_port: int = 10004
    
    # 数据库配置
    mysql_host: str = "localhost"
    mysql_user: str = "root"
    mysql_password: str = "mysql"
    mysql_db: str = "springai-alibaba-agent"
    mysql_port: int = 3306
    
    # AI配置
    llm_api_key: Optional[str] = None
    embedding_model: str = "text-embedding-ada-002"
    
    # MCP配置
    mcp_servers_config_path: str = "resources/mcp_servers_config.json"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()
